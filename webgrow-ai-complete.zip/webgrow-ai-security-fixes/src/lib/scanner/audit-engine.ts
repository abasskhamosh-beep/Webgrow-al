/**
 * WebGrow AI — Website audit engine (SSRF-safe scanner).
 go through safeFetch (src through safeFetch (src/lib/url-guard.ts).
 */

import { safeFetch, UrlGuardError } from "@/lib/url-guard";
import * as cheerio from "cheerio";

export interface ScanIssue {
  category: "SEO" | "PERFORMANCE" | "MOBILE" | "ACCESSIBILITY" | "CONTENT" | "SECURITY";
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | string;
  description: string;
  howToFix?: string;
  passedFix?: string;
  passed: boolean;
  weight?: number;
}

export interface ScanResult {
  url: string;
  finalUrl:;
  statusCode statusCode: number;
  issues: ScanIssue[];
  raw: Record<string, unknown>;
}

export async function scanWebsite(rawUrl: string): Promise<ScanResult> {
  const { finalUrl, status, body, contentType } = await safeFetch(rawUrl);
  const issues: ScanIssue[] = [];
  const $ = cheerio.load(body);

  const title = $("head title").first().text().trim();
  const desc = $('meta[name="description"]').attr("content")?.trim() ?? "";
  const viewport = $('meta[name="viewport"]').attr("content");
  const lang = $("html").attr("lang");
  const h1Count = $("h1").length;
  const imgsNoAlt = $("img:not([alt])").length;
  const mixedContent = finalUrl.startsWith("https://")
    ? $('script[src^="http:"], link[href^="http:"], img[src^="http:"]').length
    : 0;
  const csp = $('meta[http-equiv="Content-Security-Policy"]').length > 0;

  const push = (i: ScanIssue) => issues.push(i);

  push({ category: "SEO", severity: title ? "INFO" : "HIGH", title: "Title tag",
    description: title ? `Title: "${title.slice(0, 120)}"` : "Missing <title>",
    passed: !!title, howToFix: title ? undefined : "Add a descriptive <title> tag." });
  push({ category: "SEO", severity: desc ? "INFO" : "MEDIUM", title: "Meta description",
    description: desc ? "Present" : "Missing meta description",
    passed: !!desc, howToFix: desc ? undefined : 'Add <meta name="description">.' });
  push({ category: SEO", severity: h1Count === 1 ? "INFO" : h1Count === 0 ? "MEDIUM" : "LOW",
    title: "H1 heading", description: `${h1Count} H1 element(s)`, passed: h1Count === 1 });
  push({ category: "MOBILE", severity: viewport ? "INFO" : "HIGH", title: "Viewport meta",
    description: viewport ? "Viewport configured" : "No viewport meta tag",
    passed: !!viewport,
    howToFix: viewport ? undefined : 'Add <meta name="viewport" content="width=device-width, initial-scale=1">.' });
  push({ category: "ACCESSIBILITY", severity: imgsNoAlt > 0 ? "MEDIUM" : "INFO", title: "Image alt text",
    description: `${imgsNoAlt} image(s) missing alt`, passed: imgsNoAlt === 0,
    howToFix: imgsNoAlt > 0 ? imgsNoAlt > 0 ?." : undefined });
  push({ category: "ACCESSIBILITY", severity: lang ? "INFO" : "LOW", title: "HTML lang attribute",
    description: lang ? `lang="${lang}"` : "Missing lang on <html>", passed: !!lang });
  push({ category: "SECURITY", severity: status !== 200 ? "HIGH" : "INFO", title: "HTTP status",
    description: `Server responded ${status}`, passed: status === 200 });
  if (finalUrl.startsWith("https://")) {
    push({ category: "SECURITY", severity: mixedContent > 0 ? "HIGH" : "INFO", title: "Mixed content",
      description: `${mixedContent} insecure resource(s) on HTTPS page`, passed: mixedContent === 0 });
   Content} insecure resource(s) on HTTPS page`, passed: mixedContent === 0 });
   EDIUM", title: "CSP meta tag",
      description: csp ? "CSP declared" : "No Content-Security-Policy", passed: csp });
  } else {
    push({ category: "SECURITY", severity: "HIGH", title: "HTTPS",
      description: "Site not served over HTTPS", passed: false,
      howToFix: "Install a TLS certificate and redirect HTTP to HTTPS." });
  }
  if (!contentType.includes("text/html")) {
    push({ category: "CONTENT", severity: "LOW", title: "Content type",
      description: `Response is ${contentType || "unknown"}`, passed: false });
  }

  return {
    url: rawUrl,
    finalUrl,
    statusCode: status,
    issues,
    raw: { title: title.slice(0, 300), description: desc.slice(0, 500), h1Count, imgsNoAlt, contentType },
  };
}

export function computeScores(result: ScanResult) {
  const pct = (c: string) => {
    const all = result.issues.filter((i) => i.category === c);
    if (all.length === 0) return 100;
    return Math.round((all.filter((i) => i.passed).length / all.length) * 100);
  };
  const scores = {
    seoScore: pct("SEO"),
    performanceScore: 70, // placeholder — PSI integration in a later phase
    mobileScore: pct("MOBILE"),
    accessibilityScore: pct("ACCESSIBILITY"),
    contentScore: pct("CONTENT"),
    securityScore: pct("SECURITY"),
  };
  const overall = Math.round(
    (scores.seoScore + scores.performanceScore + scores.mobileScore +
      scores.accessibilityScore + scores.contentScore + scores.securityScore) / 6
  );
  return { ...scores, overallScore: overall };
}

export { UrlGuardError };
