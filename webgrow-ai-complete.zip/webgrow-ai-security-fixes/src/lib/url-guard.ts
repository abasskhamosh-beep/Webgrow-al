/**
 * WebGrow AI — SSRF-safe URL fetching.
 *
 * Security model:
 *  1. Only http/https, standard ports, no credentials in URL.
 *  2. Hostname must be a public FQDN or public IP (no localhost, *.local,
 *     *.internal, no private/reserved IP ranges, no cloud metadata IPs).
 *  3. DNS is resolved server-side and EVERY resolved address is validated;
 *     we connect to a validated public IP directly (IP pinning) so a DNS
 *     rebinding second lookup cannot return a private address.
 *  4. Redirects are followed manually and every hop is re-validated.
 *  5. Timeouts and response size limits.
 */

import { lookup } from "node:dns/promises";
import net from "node:net";

export class UrlGuardError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "UrlGuardError";
  }
}

const ALLOWED_PROTOCOLS = new Set(["http:", "https:"]);
const ALLOWED_PORTS = new Set(["", "80", "443", "8080", "8443"]);
const MAX_REDIRECTS = 3;
const MAX_BODY_BYTES = 2 * 1024 * 1024; // 2 MB
const FETCH_TIMEOUT_MS = 15_000;

const BLOCKED_HOSTNAMES =
  /^(localhost|ip6-localhost|ip6-loopback|.*\.local|.*\.localhost|.*\.internal|.*\.localdomain|metadata\.google\.internal|metadata\.google\.com|169\.254\.169\.254)$/i;

/** True if the IP address is private/reserved/metadata and must be blocked. */
export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 || // 0.0.0.0/8 "this network"
      a === 10 || // 10/8
      a === 127 || // loopback
      (a === 100 && b >= 64 && b <= 127) || // CGNAT 100.64/10
      (a === 169 && b === 254) || // link-local (incl. cloud metadata 169.254.169.254)
      (a === 172 && b >= 16 && b <= 31) || // 172.16/12
      (a === 192 && b === 168) || // 192.168/16
      (a === 198 && (b === 18 || b === 19)) || // benchmark 198.18/15
      a >= 224 // multicast + reserved 240/4 + broadcast
    );
  }
  // IPv6
  const v6 = ip.toLowerCase();
  if (v6 === "::" || v6 === "::1") return true;
  if (/^fe[89ab]/.test(v6)) return true; // link-local fe80::/10
  if (/^f[cd]/.test(v6)) return true; // unique-local fc00::/7
  if (v6.startsWith("::ffff:")) return isPrivateIp(v6.slice(7)); // IPv4-mapped
  if (v6.startsWith("64:ff9b:")) return true; // NAT64 — treat as internal
  const first = parseInt(v6.split(":")[0] || "0", 16);
  if (!Number.isNaN(first) && (first & 0xff00) === 0xff00) return true; // multicast
  return false;
}

/** Validate the URL string itself (protocol, port, credentials, hostname). */
export function assertPublicHttpUrl(input: string): URL {
  let value = String(input ?? "").trim();
  if (value.length > 2048) throw new UrlGuardError("URL too long");
  if (/[\u0000-\u001f\u007f]/.test(value)) throw new UrlGuardError("Invalid URL");
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;

  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new UrlGuardError("Invalid URL");
  }

  if (!ALLOWED_PROTOCOLS.has(url.protocol)) throw new UrlGuardError("Only http/https allowed");
  if (!ALLOWED_PORTS.has(url.port)) throw new UrlGuardError("Port not allowed");
  if (url.username || url.password) throw new UrlGuardError("Credentials in URL not allowed");

  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (!host || BLOCKED_HOSTNAMES.test(host)) throw new UrlGuardError("Blocked hostname");
  // Reject octal / decimal / hex IP encodings that could evade string filters.
  if (/^0x/i.test(host) || /^\d{8,}$/.test(host) || /(^|\.)0\d/.test(host)) {
    throw new UrlGuardError("Encoded IP addresses are not allowed");
  }
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new UrlGuardError("Private IP addresses are not allowed");
  } else {
    if (!host.includes(".")) throw new UrlGuardError("Invalid hostname");
    if (host.endsWith(".")) throw new UrlGuardError("Invalid hostname");
  }
  return url;
}

/** Resolve DNS and verify every address is public. Returns a pinned IP. */
async function resolveAndValidate(url: URL): Promise<string> {
  const host = url.hostname.replace(/^\[|\]$/g, "");
  let addresses: { address: string; family: number }[];
  try {
    addresses = await lookup(host, { all: true, verbatim: true });
  } catch {
    throw new UrlGuardError("DNS resolution failed");
  }
  if (addresses.length === 0) throw new UrlGuardError("No DNS records");
  const publics = addresses.filter((a) => !isPrivateIp(a.address));
  if (publics.length === 0) {
    throw new UrlGuardError("Host resolves to a private/reserved address");
  }
  return publics[0].address;
}

export interface SafeFetchResult {
  finalUrl: string;
  status: number;
  headers: Headers;
  body: string;
  contentType: string;
}

/**
 * SSRF-safe fetch. DNS is resolved and validated first; the connection is
 * made to the validated IP while keeping Host/SNI = original is
 * made to the validated IP while keeping Host/SNI = original hostname.
 * Redirect(
  rawUrl: string,
  init: { method?: string; headers?: Record<string, string> } = {}
): Promise<SafeFetchResult> {
  let currentUrl = assertPublicHttpUrl(rawUrl);

  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const pinnedIp = await resolveAndValidate(currentUrl);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
      // Node 18+/undici: pin the connection to the validated IP, keep SNI/Host.
      const { Agent } = await import("undici").catch(() => ({ Agent: undefined as never }));
      const dispatcher = Agent
        ? new Agent({
            connect: { host: pinnedIp, servername: currentUrl.hostname },
            maxRedirections: 0,
          })
        : undefined;

      const res = await fetch(currentUrl.toString(), {
        method: init.method ?? "GET",
        redirect: "manual",
        signal: controller.signal,
        headers: {
          "User-Agent": "WebGrowAI-AuditBot/1.0 (+https://webgrow.ai/bot)",
          Accept: "text/html,application/xhtml+xml",
          "Accept-Language": "en;q=0.8,fa;q=0.6",
          ...(init.headers ?? {}),
        },
        ...(dispatcher ? { dispatcher } : {}),
      } as RequestInit);

      if ([301, 302, 303, 307, 308].includes(res.status)) {
        const loc = res.headers.get("location");
        if (!loc) throw new UrlGuardError("Redirect without Location header");
        await res.body?.cancel();
        currentUrl = assertPublicHttpUrl(new URL(loc, currentUrl).toString());
        continue;
      }

      const contentType = res.headers.get("content-type") ?? "";
      const lenHeader = Number(res.headers.get("content-length") ?? "0");
      if (lenHeader > MAX_BODY_BYTES) throw new UrlGuardError("Response too large");

      const reader = res.body?.getReader();
      let text = "";
      let received = 0;
      if (reader) {
        const decoder = new TextDecoder("utf-8", { fatal: false });
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          received += value.byteLength;
          if (received > MAX_BODY_BYTES) {
            await reader.cancel();
            throw new UrlGuardError("Response body exceeds size limit");
          }
          text += decoder.decode(value, { stream: true });
        }
      }
      return {
        finalUrl: currentUrl.toString(),
        status: res.status,
        headers: res.headers,
        body: text,
        contentType,
      };
    } finally {
      clearTimeout(timer);
    }
  }
  throw new UrlGuardError finally {
      clearTimeout(timer);
    }
  }
  throw new UrlGuardError MAX_REDIRECTS };
