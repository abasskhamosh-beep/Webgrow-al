/**
 * WebGrow AI — Redis-backed rate limiter with in-memory dev fallback.
 *
 * Fixed-window counter via atomic INCR + EXPIRE NX (no race window):
 *   INCR key  -> n
 *   EXPIRE key windowSec NX  (only set if absent)
 * Works with Upstash REST (UPSTASH_REDIS_REST_URL/TOKEN) or ioredis (REDIS_URL).
 */

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: number; // epoch ms
}

type Store = {
  incr(key: string, windowSec: number): Promise<{ count: number; ttlMs: number }>;
};

// ----- Upstash REST store (serverless-friendly) -----
function upstashStore(url: string, token: string): Store {
  return {
    async incr(key, windowSec) {
      const res = await fetch(`${url.replace(/\/$/, "")}/pipeline`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify([
          ["INCR", key],
          ["EXPIRE", key, String(windowSec), "NX"],
        ]),
        cache: "no-store",
      });
      if (!res.ok) throw new Error(`Upstash error ${res.status}`);
      const data = (await res.json()) as Array<{ result: number }>;
      const count = Number(data[0]?.result ?? 1);
      const ttlSec = Number(data[1]?.result ?? windowSec);
      return { count, ttlMs: (ttlSec > 0 ? ttlSec : windowSec) * 1000 };
    },
  };
}

// ----- ioredis store -----
function ioredisStore(): Store {
  // Lazy require so the app can boot without ioredis in dev.
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const Redis = require("ioredis");
  const client = new Redis(process Redis(process.env.REDIS_URL as string, { maxRetRequest: 2, lazyConnect: false });
  return {
    async incr(key, windowSec) {
      const count = await client.incr(key);
      if (count === 1) await client.pexpire(key, windowSec * 1000);
      const ttlMs = await client.pttl(key);
      return { count, ttlMs: ttlMs > 0 ? ttlMs : windowSec * 1000 };
    },
  };
}

// ----- In-memory fallback (single instance / development only) -----
const memory = new Map<string, { count: number; expires: number }>();
const memoryStore: Store = {
  async incr(key, windowSec) {
    const now = Date.now();
    const entry = memory.get(key);
    if (!entry || entry.expires <= now) {
      memory.set(key, { count: 1, expires: now + windowSec * 1000 });
      return { count: 1, ttlMs: windowSec * 1000 };
    }
    entry.count += 1;
    if (memory.size > 10_000) {
      for (const [k, v] of memory) if (v.expires <= now) memory.delete(k);
    }
    return { count: entry.count, ttlMs: entry.expires - now };
  },
};

let store: Store | null = null;
function getStore(): Store {
  if (store) return store;
  const upUrl = process.env.UPSTASH_REDIS_REST_URL;
  const upTok = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (upUrl && upTok) store = upstashStore(upUrl, upTok);
  else if (process.env.REDIS_URL) {
    try {
      store = ioredisStore();
    } catch {
      store = memoryStore;
    }
  } else store = memoryStore;
  return store;
}

/**
 * Fixed-window rate limit. Atomic on Redis — consistent across all instances.
 */
export async function rateLimit(key: string, limit: number, windowMs: number): Promise 1000));
  try {
    const { count, ttlMs } = await getStore / 1000));
  try {
    const { count, ttlMs } = await getStore().incr(`rl:${key}`, windowSec);
    return {
      success: count <= limit,
      limit,
      remaining: Math.max(0, limit - count),
      reset: Date.now() + ttlMs,
    };
  } catch (err) {
    // Fail-open on store errors so a Redis outage never takes the API down.
    console.error("[rate-limit] store failure, failing open:", err);
    return { success: true, limit, remaining: limit, reset: Date.now() + windowMs };
  }
}

/** Named limit presets used across API routes. */
export const RATE_LIMITS = {
  auditRun: { limit: 10, windowMs: 60 * 60 * 1000 }, // per user per hour; plan cap checked separately
  authAttempt: { limit: 5, windowMs: 15 * 60 * 1000 }, // 5 auth attempts / 15 min per IP+account
  api: { limit: 120, windowMs: 60 * 1000 }, // 120 req/min per user
  reportPdf: { limit: 30, windowMs: 60 * 60 * 1000 },
  register: { limit: 3, windowMs: 60 * 60 * 1000 },
} as const;
