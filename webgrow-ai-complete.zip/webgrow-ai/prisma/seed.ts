// Idempotent seed: demo user + FREE subscription + one website.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("demo1234", 12);

  const user = await prisma.user.upsert({
    where: { email: "demo@webgrow.ai" },
    update: { passwordHash },
    create: {
      email: "demo@webgrow.ai",
      name: "Demo User",
      passwordHash,
      locale: "en",
      role: "USER",
    },
  });

  await prisma.subscription.upsert({
    where: { userId: user.id },
    update: { plan: "FREE", status: "ACTIVE" },
    create: { userId: user.id, plan: "FREE", status: "ACTIVE" },
  });

  await prisma.website.upsert({
    where: { userId_url: { userId: user.id, url: "https://example.com" } },
    update: {},
    create: { userId: user.id, url: "https://example.com", name: "Example" },
  });

  console.log("Seed complete: demo@webgrow.ai / demo1234");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
