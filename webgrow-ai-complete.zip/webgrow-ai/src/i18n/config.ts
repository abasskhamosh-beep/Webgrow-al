// Supported locales for the WebGrow AI app.
export const locales = ["en", "fa"] as const;

export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "en";

// Human-readable locale names shown in the language switcher.
export const localeNames: Record<Locale, string> = { en: "English", fa: "فارسی" };

// Type guard: check whether a string is a supported locale.
export function isValidLocale(value: string): value is Locale {
  return (locales as readonly string[]).includes(value);
}

// Whether the locale is written right-to-left.
export function isRtl(locale: Locale): boolean {
  return locale === "fa";
}

// CSS "direction" value for a locale.
export function dir(locale: Locale): "ltr" | "rtl" {
  return isRtl(locale) ? "rtl" : "ltr";
}
