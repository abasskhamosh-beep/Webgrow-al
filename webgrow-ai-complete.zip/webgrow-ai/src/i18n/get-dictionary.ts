// This module is server-only. Do not import it from client components.
import type { Locale } from "./config";
import { defaultLocale } from "./config";

// The dictionary shape is inferred from the English source of truth.
export type Dictionary = typeof import("./dictionaries/en.json");

// Lazy loaders for each locale dictionary.
const dictionaries: Record<Locale, () => Promise<Dictionary>> = {
  en: () => import("./dictionaries/en.json").then((m) => m.default),
  fa: () => import("./dictionaries/fa.json").then((m) => m.default),
};

// Load the dictionary for a locale, falling back to the default locale.
export async function getDictionary(locale: Locale): Promise<Dictionary> {
  const key = isValid(locale) ? locale : defaultLocale;
  return dictionaries[key]();
}
