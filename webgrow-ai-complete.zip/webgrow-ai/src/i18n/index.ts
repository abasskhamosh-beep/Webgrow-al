// Public i18n entry point.
export * from "./config";
export * from "./get-dictionary";
export type { Dictionary } from "./get-dictionary";
