import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merge Tailwind classes with conflict resolution. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Locale-aware date formatting (en / fa). */
export function formatDate(date: Date, locale: string = "en"): string {
  return new Intl.DateTimeFormat(locale === "fa" ? "fa-IR" : "en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(date);
}

/**
 * Normalize a website URL: add https:// if missing, validate,
 * strip the trailing slash. Throws on invalid input.
 */
export function normalizeUrl(input: string): string {
  let value = input.trim();
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Invalid URL");
  }
  if (!/^https?:$/.test(url.protocol) || !url.hostname.includes(".")) {
    throw new Error("Invalid URL");
  }
  return url.toString().replace(/\/$/, "");
}

/** Tailwind color class for a 0-100 score. */
export function scoreColor(score: number): string {
  if (score >= 90) return "text-success";
  if (score >= 50) return "text-warning";
  return "text-destructive";
}

/** Human label for a 0-100 score, localized. */
export function scoreLabel(score: number, locale: string = "en"): string {
  const fa = locale === "fa";
  if (score >= 90) return fa ? "عالی" : "Excellent";
  if (score >= 75) return fa ? "خوب" : "Good";
  if (score >= 50) return fa ? "نیاز به بهبود" : "Needs work";
  return fa ? "ضعیف" : "Poor";
}
