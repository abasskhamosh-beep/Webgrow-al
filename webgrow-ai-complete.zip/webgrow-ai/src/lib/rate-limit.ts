/**
 * In-memory sliding-window rate limiter.
 * NOTE: This works for a single instance only. In production, swap the
 * Map for Upstash Redis (or another shared store) so limits hold across
 * serverless instances.
 */
const buckets = new Map<string, number[]>();

export interface RateLimitResult {
  success: boolean;
  remaining: number;
  reset: number; // epoch ms when the window resets
}

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  const windowStart = now - windowMs;
  const hits = (buckets.get(key) ?? []).filter((t) => t > windowStart);

  if (hits.length >= limit) {
    return { success: false, remaining: 0, reset: hits[0] + windowMs };
  }
  hits.push(now);
  buckets.set(key, hits);

  // Opportunistic cleanup to bound memory.
  if (buckets.size > 10_000) {
    for (const [k, v] of buckets) {
      if (v.every((t) => t <= windowStart)) buckets.delete(k);
    }
  }
  return { success: true, remaining: limit - hits.length, reset: now + windowMs };
}
