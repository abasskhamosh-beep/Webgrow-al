/**
 * WebGrow AI — PDF Report System Types
 * Shared types for the premium website audit PDF report generator.
 */

export type AuditCategory =
  | "seo"
  | "performance"
  | "mobile"
  | "accessibility"
  | "content"
  | "security";

export type IssueSeverity = "critical" | "warning" | "info";

export type PlanTier = "FREE" | "PRO" | "AGENCY";

export interface AuditIssue {
  /** Short title, e.g. "Missing meta description" */
  title: string;
  /** Severity of the finding */
  severity: IssueSeverity;
  /** Human-readable explanation of the problem */
  description: string;
  /** Which category the issue belongs to */
  category: AuditCategory;
  /** Actionable fix suggestion */
  recommendation?: string;
}

export interface CategoryAnalysis {
  category: AuditCategory;
  /** 0–100 score */
  score: number;
  /** One-paragraph narrative summary */
  summary: string;
  /** Bullet-point findings for this category */
  findings: string[];
}

export interface AiRecommendation {
  title: string;
  description: string;
  /** Estimated impact, e.g. "high" | "medium" | "low" */
  impact: "high" | "medium" | "low";
  category?: AuditCategory;
}

export interface QuickWin {
  title: string;
  description: string;
  /** Estimated time, e.g. "under 1 hour" */
  effort?: string;
}

export interface ActionPlanWeek {
  week: number;
  focus: string;
  tasks: string[];
}

export interface AuditInsights {
  /** One-paragraph executive summary of the whole audit */
  executiveSummary?: string;
  analyses?: Partial<Record<AuditCategory, { summary: string; findings: string[] }>>;
  recommendations?: AiRecommendation[];
  quickWins?: QuickWin[];
  actionPlan?: ActionPlanWeek[];
  /** Concluding paragraph for the final page */
  conclusion?: string;
}

/** Raw JSON columns stored on the AuditResult model */
export interface AuditIssuesPayload {
  issues?: AuditIssue[];
}

export interface AuditResultData {
  id: string;
  url: string;
  createdAt: Date | string;
  overallScore: number;
  seoScore: number;
  performanceScore: number;
  mobileScore: number;
  accessibilityScore: number;
  contentScore: number;
  securityScore: number;
  issues: AuditIssuesPayload | AuditIssue[] | null;
  aiInsights: AuditInsights | null;
  status?: string;
}

/** Branding merged by white-label helpers */
export interface Branding {
  /** true when rendering under an agency's white-label branding */
  whiteLabel: boolean;
  logoUrl?: string;
  companyName: string;
  website: string;
  contactEmail: string;
  contactPhone?: string;
  /** Hex color, e.g. #0D9488 */
  primaryColor: string;
  /** Optional footer note, e.g. "Report prepared by Acme Agency" */
  footerNote?: string;
}

export interface ReportOptions {
  branding: Branding;
  audit: AuditResultData;
  /** Filename (without extension) used in Content-Disposition */
  fileName?: string;
}

export interface GeneratedReport {
  buffer: Buffer;
  fileName: string;
}
