/**
 * WebGrow AI — PDF report generator.
 *
 * Merges white-label branding, renders the premium report template and
 * returns a downloadable PDF buffer with a safe filename.
 */

import { renderReportPdf } from "./report-template";
import { mergeWhiteLabelBranding, type WhiteLabelSettingsRecord } from "./white-label";
import type { AuditResultData, GeneratedReport, ReportOptions, Branding } from "./types";

/** Extract a hostname (domain) from a URL, stripping www. Falls back to input. */
export function extractDomain(url: string): string {
  try {
    const withProtocol = url.startsWith("http") ? url : `https://${url}`;
    const { hostname } = new URL(withProtocol);
    return hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    const cleaned = url
      .replace(/^https?:\/\//i, "")
      .replace(/^www\./i, "")
      .split(/[/?#]/)[0];
    return cleaned || "site";
  }
}

/** Build a safe report filename: webgrow-report-<domain>-<date>.pdf */
export function buildReportFileName(url: string, date: Date = new Date()): string {
  const domain = extractDomain(url).replace(/[^a-z0-9.-]/gi, "-");
  const dateStr = date.toISOString().slice(0, 10);
  return `webgrow-report-${domain}-${dateStr}.pdf`;
}

export interface GenerateReportInput {
  /** Full audit record (Prisma Audit mapped to AuditResultData). */
  audit: AuditResultData;
  /** Agency white-label settings, if any. */
  whiteLabelSettings?: WhiteLabelSettingsRecord | null;
  /** Plan tier used to decide whether white-label branding applies. */
  planTier?: string | null;
}

/**
 * Generate the PDF report.
 * Returns exactly the GeneratedReport shape: { buffer, fileName }.
 */
export async function generateReport({
  audit,
  whiteLabelSettings = null,
  planTier,
}: GenerateReportInput): Promise<GeneratedReport> {
  const branding: Branding = mergeWhiteLabelBranding(whiteLabelSettings, planTier);

  const options: ReportOptions = {
    branding,
    audit,
    fileName: buildReportFileName(audit.url, new Date(audit.createdAt)).replace(
      /\.pdf$/,
      ""
    ),
  };

  const buffer = await renderReportPdf(options);

  return {
    buffer,
    fileName: options.fileName + ".pdf",
  };
}
