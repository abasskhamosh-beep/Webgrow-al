/**
 * WebGrow AI — White-label configuration and branding merge helper.
 *
 * Agency-tier users can override the default WebGrow AI branding with their
 * own logo, company name, website and contact info so the generated PDF can
 * be sent directly to their clients.
 */

import type { Branding, PlanTier } from "./types";

/** Brand colors used across the PDF template. */
export const BRAND_COLORS = {
  /** Dark navy header */
  navy: "#0F172A",
  /** Accent teal */
  teal: "#0D9488",
  /** Light teal tint for backgrounds */
  tealLight: "#CCFBF1",
  /** Muted slate text */
  slate: "#64748B",
  /** Dark body text */
  slateDark: "#1E293B",
  /** Light divider */
  border: "#E2E8F0",
  /** Section background */
  background: "#F8FAFC",
} as const;

/** Severity accent colors. */
export const SEVERITY_COLORS = {
  critical: "#DC2626",
  warning: "#D97706",
  info: "#0284C7",
} as const;

/** Default WebGrow AI branding. */
export const DEFAULT_BRANDING: Branding = {
  whiteLabel: false,
  companyName: "WebGrow AI",
  website: "https://webgrow.ai",
  contactEmail: "hello@webgrow.ai",
  primaryColor: BRAND_COLORS.teal,
  footerNote: "Powered by WebGrow AI — AI-Powered Website Audits",
};

/** Prisma model shape for WhiteLabelSettings. */
export interface WhiteLabelSettingsRecord {
  userId: string;
  logoUrl?: string | null;
  companyName?: string | null;
  website?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  primaryColor?: string | null;
}

/** Agency plans that are allowed to white-label reports. */
const WHITE_LABEL_PLANS: ReadonlySet<PlanTier> = new Set<PlanTier>(["AGENCY"]);

/**
 * Whether the given plan tier may white-label reports.
 * Mirrors the plans.ts feature-flag pattern.
 */
export function canWhiteLabel(
  planTier: PlanTier | string | undefined | null
): boolean {
  if (!planTier) return false;
  return WHITE_LABEL_PLANS.has(planTier as PlanTier);
}

/**
 * Merge an agency's WhiteLabelSettings with the default WebGrow AI branding.
 * Missing/blank fields fall back to the WebGrow AI defaults, so the report
 * always renders with complete branding.
 */
export function mergeWhiteLabelBranding(
  settings: WhiteLabelSettingsRecord | null | undefined,
  planTier?: PlanTier | string | null
): Branding {
  if (!settings || !canWhiteLabel(planTier)) {
    return { ...DEFAULT_BRANDING };
  }

  const pick = (value: string | null | undefined, fallback: string): string => {
    const trimmed = typeof value === "string" ? value.trim() : "";
    return trimmed.length > 0 ? trimmed : fallback;
  };

  const companyName = pick(settings.companyName, DEFAULT_BRANDING.companyName);

  return {
    whiteLabel: true,
    logoUrl: settings.logoUrl?.trim() || undefined,
    companyName,
    website: pick(settings.website, DEFAULT_BRANDING.website),
    contactEmail: pick(settings.contactEmail, DEFAULT_BRANDING.contactEmail),
    contactPhone: settings.contactPhone?.trim() || undefined,
    primaryColor: pick(settings.primaryColor, DEFAULT_BRANDING.primaryColor),
    footerNote:
      companyName === DEFAULT_BRANDING.companyName
        ? DEFAULT_BRANDING.footerNote
        : `Report prepared by ${companyName}`,
  };
}
