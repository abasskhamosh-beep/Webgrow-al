/**
 * WebGrow AI — Premium PDF report template (@react-pdf/renderer).
 *
 * Agency-quality layout:
 *  - Branded cover page (URL, audit date, overall score)
 *  - Executive summary
 *  - Category score bars
 *  - Critical issues & warnings
 *  - Detailed per-category analysis
 *  - AI recommendations, quick wins, 30-day action plan
 *  - Final summary / conclusion
 *  - Branded footer on every page
 */

import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  renderToBuffer,
  Font,
} from "@react-pdf/renderer";

import type {
  AuditCategory,
  AuditIssue,
  AuditResultData,
  Branding,
} from "./types";
import { BRAND_COLORS, SEVERITY_COLORS } from "./white-label";

// ---------------------------------------------------------------------------
// Typography — register clean, professional fonts (bundled with react-pdf).
// ---------------------------------------------------------------------------
Font.register({
  family: "Helvetica",
  fonts: [
    { src: "Helvetica" },
    { src: "Helvetica-Bold", fontWeight: 700 },
    { src: "Helvetica-Oblique", fontStyle: "italic" },
  ],
});

const C = BRAND_COLORS;

const styles = StyleSheet.create({
  page: {
    fontFamily: "Helvetica",
    fontSize: 10,
    color: C.slateDark,
    backgroundColor: "#FFFFFF",
    paddingTop: 40,
    paddingBottom: 70,
    paddingHorizontal: 48,
    lineHeight: 1.5,
  },
  coverPage: {
    fontFamily: "Helvetica",
    backgroundColor: C.navy,
    color: "#FFFFFF",
    paddingTop: 70,
    paddingBottom: 70,
    paddingHorizontal: 56,
  },
  // ---- Footer -------------------------------------------------------------
  footer: {
    position: "absolute",
    bottom: 28,
    left: 48,
    right: 48,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: C.border,
    paddingTop: 8,
  },
  footerBrand: { fontSize: 8, color: C.slate },
  footerPage: { fontSize: 8, color: C.slate },
  // ---- Cover --------------------------------------------------------------
  coverLogo: { height: 42, objectFit: "contain", marginBottom: 24 },
  coverLogoFallback: {
    fontSize: 26,
    fontWeight: 700,
    color: "#FFFFFF",
    marginBottom: 24,
  },
  coverEyebrow: {
    fontSize: 11,
    color: "#5EEAD4",
    marginBottom: 8,
    letterSpacing: 2,
  },
  coverTitle: {
    fontSize: 30,
    fontWeight: 700,
    color: "#FFFFFF",
    marginBottom: 6,
  },
  coverUrl: { fontSize: 15, color: "#94A3B8", marginBottom: 36 },
  coverScoreCard: {
    backgroundColor: "rgba(13, 148, 136, 0.18)",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: C.teal,
    padding: 24,
    marginBottom: 36,
    flexDirection: "row",
    alignItems: "center",
  },
  coverScoreNumber: {
    fontSize: 52,
    fontWeight: 700,
    color: "#5EEAD4",
    marginRight: 20,
  },
  coverScoreLabel: { fontSize: 12, color: "#CBD5E1", marginBottom: 4 },
  coverScoreGrade: { fontSize: 16, fontWeight: 700, color: "#FFFFFF" },
  coverMeta: { flexDirection: "row" },
  coverMetaItem: { marginRight: 48 },
  coverMetaLabel: {
    fontSize: 8,
    color: "#64748B",
    marginBottom: 3,
    letterSpacing: 1,
  },
  coverMetaValue: { fontSize: 11, color: "#E2E8F0" },
  // ---- Sections -----------------------------------------------------------
  section: { marginTop: 22 },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 700,
    color: C.navy,
    marginBottom: 4,
  },
  sectionRule: {
    height: 3,
    width: 40,
    backgroundColor: C.teal,
    borderRadius: 2,
    marginBottom: 12,
  },
  paragraph: { fontSize: 10, color: C.slate, textAlign: "justify" },
  // ---- Score bars ---------------------------------------------------------
  scoreRow: { marginBottom: 9 },
  scoreHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 3,
  },
  scoreLabel: { fontSize: 9, fontWeight: 700, color: C.slateDark },
  scoreValue: { fontSize: 9, fontWeight: 700 },
  scoreTrack: {
    height: 7,
    backgroundColor: "#E2E8F0",
    borderRadius: 4,
    overflow: "hidden",
  },
  scoreFill: { height: 7, borderRadius: 4 },
  // ---- Cards / lists ------------------------------------------------------
  card: {
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 6,
    padding: 12,
    marginBottom: 10,
  },
  cardTitle: { fontSize: 10, fontWeight: 700, color: C.slateDark, marginBottom: 3 },
  cardText: { fontSize: 9, color: C.slate, marginBottom: 3 },
  severityTag: {
    fontSize: 8,
    fontWeight: 700,
    color: "#FFFFFF",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3,
    marginRight: 8,
    textTransform: "uppercase",
  },
  bulletRow: { flexDirection: "row", marginBottom: 4, paddingRight: 8 },
  bullet: { width: 12, fontSize: 10, color: C.teal, fontWeight: 700 },
  bulletText: { flex: 1, fontSize: 9, color: C.slate },
  badge: {
    fontSize: 8,
    fontWeight: 700,
    color: "#FFFFFF",
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 3,
    marginRight: 8,
    textTransform: "uppercase",
  },
  // ---- Action plan --------------------------------------------------------
  weekCard: {
    borderLeftWidth: 3,
    borderLeftColor: C.teal,
    backgroundColor: C.background,
    borderRadius: 4,
    padding: 12,
    marginBottom: 10,
  },
  weekTitle: { fontSize: 10, fontWeight: 700, color: C.navy, marginBottom: 2 },
  weekFocus: { fontSize: 9, color: C.teal, marginBottom: 6 },
  // ---- Overall summary grid ----------------------------------------------
  summaryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 4,
  },
  summaryCell: {
    width: "33.33%",
    padding: 10,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 6,
    marginBottom: 8,
  },
  summaryCellScore: { fontSize: 20, fontWeight: 700, marginBottom: 2 },
  summaryCellLabel: { fontSize: 8, color: C.slate, letterSpacing: 0.5 },
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CATEGORIES: { key: AuditCategory; label: string }[] = [
  { key: "seo", label: "SEO" },
  { key: "performance", label: "Performance" },
  { key: "mobile", label: "Mobile" },
  { key: "accessibility", label: "Accessibility" },
  { key: "content", label: "Content" },
  { key: "security", label: "Security" },
];

function scoreColor(score: number): string {
  if (score >= 80) return "#059669";
  if (score >= 60) return "#D97706";
  return "#DC2626";
}

function gradeLabel(score: number): string {
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 50) return "Needs Improvement";
  return "Critical";
}

function categoryScore(audit: AuditResultData, key: AuditCategory): number {
  switch (key) {
    case "seo":
      return audit.seoScore;
    case "performance":
      return audit.performanceScore;
    case "mobile":
      return audit.mobileScore;
    case "accessibility":
      return audit.accessibilityScore;
    case "content":
      return audit.contentScore;
    case "security":
      return audit.securityScore;
  }
}

function normalizeIssues(
  issues: AuditResultData["issues"]
): AuditIssue[] {
  if (!issues) return [];
  if (Array.isArray(issues)) return issues;
  if (Array.isArray((issues as { issues?: AuditIssue[] }).issues)) {
    return (issues as { issues: AuditIssue[] }).issues;
  }
  return [];
}

function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// ---------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------

interface BrandHeaderProps {
  branding: Branding;
}

function LogoMark({ branding }: BrandHeaderProps) {
  if (branding.logoUrl) {
    return <Image src={branding.logoUrl} style={styles.coverLogo} />;
  }
  return (
    <Text style={styles.coverLogoFallback}>
      {branding.companyName}
      {!branding.whiteLabel && <Text style={{ color: "#5EEAD4" }}> AI</Text>}
    </Text>
  );
}

function Footer({ branding }: BrandHeaderProps) {
  return (
    <View style={styles.footer} fixed>
      <Text style={styles.footerBrand}>
        {branding.footerNote ??
          `${branding.companyName} — ${branding.website}`}
      </Text>
      <Text
        style={styles.footerPage}
        render={({ pageNumber, totalPages }) =>
          `Page ${pageNumber} of ${totalPages}`
        }
      />
    </View>
  );
}

function ScoreBar({ label, score }: { label: string; score: number }) {
  const clamped = Math.max(0, Math.min(100, Math.round(score)));
  return (
    <View style={styles.scoreRow} wrap={false}>
      <View style={styles.scoreHeader}>
        <Text style={styles.scoreLabel}>{label}</Text>
        <Text style={[styles.scoreValue, { color: scoreColor(clamped) }]}>
          {clamped}/100
        </Text>
      </View>
      <View style={styles.scoreTrack}>
        <View
          style={[
            styles.scoreFill,
            { width: `${clamped}%`, backgroundColor: scoreColor(clamped) },
          ]}
        />
      </View>
    </View>
  );
}

function SectionTitle({ title }: { title: string }) {
  return (
    <View style={styles.section} wrap={false}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionRule} />
    </View>
  );
}

function SeverityTag({ severity }: { severity: AuditIssue["severity"] }) {
  const label =
    severity === "critical"
      ? "Critical"
      : severity === "warning"
        ? "Warning"
        : "Info";
  return (
    <Text
      style={[
        styles.severityTag,
        { backgroundColor: SEVERITY_COLORS[severity] ?? SEVERITY_COLORS.info },
      ]}
    >
      {label}
    </Text>
  );
}

function IssueCard({ issue }: { issue: AuditIssue }) {
  return (
    <View style={styles.card} wrap={false}>
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
        <SeverityTag severity={issue.severity} />
        <Text style={styles.cardTitle}>{issue.title}</Text>
      </View>
      {issue.description ? (
        <Text style={styles.cardText}>{issue.description}</Text>
      ) : null}
      {issue.recommendation ? (
        <Text style={[styles.cardText, { color: C.teal, fontStyle: "italic" }]}>
          Fix: {issue.recommendation}
        </Text>
      ) : null}
    </View>
  );
}

function Bullets({ items }: { items: string[] }) {
  return (
    <View>
      {items.map((item, i) => (
        <View style={styles.bulletRow} key={i} wrap={false}>
          <Text style={styles.bullet}>•</Text>
          <Text style={styles.bulletText}>{item}</Text>
        </View>
      ))}
    </View>
  );
}

function CategoryAnalysisSection({
  audit,
  insights,
}: {
  audit: AuditResultData;
  insights: NonNullable<AuditResultData["aiInsights"]>;
}) {
  const analyses = insights.analyses ?? {};
  return (
    <>
      {CATEGORIES.map(({ key, label }) => {
        const analysis = analyses[key];
        const score = categoryScore(audit, key);
        return (
          <View key={key} style={styles.section}>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "flex-end",
                marginBottom: 4,
              }}
              wrap={false}
            >
              <Text style={styles.sectionTitle}>{label} Analysis</Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: 700,
                  color: scoreColor(score),
                }}
              >
                {Math.round(score)}/100
              </Text>
            </View>
            <View style={styles.sectionRule} />
            {analysis?.summary ? (
              <Text style={[styles.paragraph, { marginBottom: 8 }]}>
                {analysis.summary}
              </Text>
            ) : null}
            {analysis?.findings?.length ? (
              <Bullets items={analysis.findings} />
            ) : (
              <Text style={styles.cardText}>
                No additional {label.toLowerCase()} findings were recorded for
                this audit.
              </Text>
            )}
          </View>
        );
      })}
    </>
  );
}

// ---------------------------------------------------------------------------
// Pages
// ---------------------------------------------------------------------------

function CoverPage({ branding, audit }: BrandHeaderProps & { audit: AuditResultData }) {
  const overall = Math.round(audit.overallScore);
  return (
    <Page size="A4" style={styles.coverPage}>
      <LogoMark branding={branding} />
      <Text style={styles.coverEyebrow}>WEBSITE AUDIT REPORT</Text>
      <Text style={styles.coverTitle}>Website Growth Audit</Text>
      <Text style={styles.coverUrl}>{audit.url}</Text>

      <View style={styles.coverScoreCard}>
        <Text style={styles.coverScoreNumber}>{overall}</Text>
        <View>
          <Text style={styles.coverScoreLabel}>OVERALL HEALTH SCORE</Text>
          <Text style={styles.coverScoreGrade}>{gradeLabel(overall)}</Text>
        </View>
      </View>

      <View style={styles.coverMeta}>
        <View style={styles.coverMetaItem}>
          <Text style={styles.coverMetaLabel}>AUDIT DATE</Text>
          <Text style={styles.coverMetaValue}>{formatDate(audit.createdAt)}</Text>
        </View>
        <View style={styles.coverMetaItem}>
          <Text style={styles.coverMetaLabel}>PREPARED BY</Text>
          <Text style={styles.coverMetaValue}>{branding.companyName}</Text>
        </View>
        <View style={styles.coverMetaItem}>
          <Text style={styles.coverMetaLabel}>CONTACT</Text>
          <Text style={styles.coverMetaValue}>{branding.contactEmail}</Text>
        </View>
      </View>
    </Page>
  );
}

interface ContentPageProps {
  branding: Branding;
  audit: AuditResultData;
}

function ReportContent({ branding, audit }: ContentPageProps) {
  const insights = audit.aiInsights ?? {};
  const issues = normalizeIssues(audit.issues);
  const criticalIssues = issues.filter((i) => i.severity === "critical");
  const warnings = issues.filter((i) => i.severity === "warning");
  const analyses = insights.analyses ?? {};
  const categorySummaries = CATEGORIES.filter(({ key }) => analyses[key]);

  return (
    <>
      {/* Executive Summary */}
      <SectionTitle title="Executive Summary" />
      <Text style={styles.paragraph}>
        {insights.executiveSummary ??
          `This report presents a comprehensive AI-powered audit of ${audit.url}. The website received an overall health score of ${Math.round(audit.overallScore)}/100 (${gradeLabel(audit.overallScore)}). Below we break down performance across six key categories, highlight critical issues that need immediate attention, and provide a prioritized 30-day action plan to improve your website's visibility, speed and conversion potential.`}
      </Text>

      {/* Overall scores grid */}
      <View style={styles.section}>
        <View style={styles.summaryGrid}>
          {CATEGORIES.map(({ key, label }) => {
            const s = Math.round(categoryScore(audit, key));
            return (
              <View style={styles.summaryCell} key={key} wrap={false}>
                <Text
                  style={[styles.summaryCellScore, { color: scoreColor(s) }]}
                >
                  {s}
                </Text>
                <Text style={styles.summaryCellLabel}>{label.toUpperCase()}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Category score bars */}
      <SectionTitle title="Category Scores" />
      <View>
        {CATEGORIES.map(({ key, label }) => (
          <ScoreBar
            key={key}
            label={label}
            score={categoryScore(audit, key)}
          />
        ))}
      </View>

      {/* Critical issues */}
      {criticalIssues.length > 0 && (
        <>
          <SectionTitle title="Critical Issues" />
          <Text style={[styles.paragraph, { marginBottom: 10 }]}>
            These issues are actively harming your website's performance,
            rankings or user experience and should be fixed immediately.
          </Text>
          {criticalIssues.map((issue, i) => (
            <IssueCard issue={issue} key={i} />
          ))}
        </>
      )}

      {/* Warnings */}
      {warnings.length > 0 && (
        <>
          <SectionTitle title="Important Warnings" />
          <Text style={[styles.paragraph, { marginBottom: 10 }]}>
            These issues are not urgent but will limit your website's growth if
            left unresolved.
          </Text>
          {warnings.map((issue, i) => (
            <IssueCard issue={issue} key={i} />
          ))}
        </>
      )}

      {/* Detailed analyses */}
      {categorySummaries.length > 0 && (
        <CategoryAnalysisSection audit={audit} insights={insights} />
      )}

      {/* AI recommendations */}
      {insights.recommendations && insights.recommendations.length > 0 && (
        <>
          <SectionTitle title="AI Recommendations" />
          {insights.recommendations.map((rec, i) => (
            <View style={styles.card} key={i} wrap={false}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 4,
                }}
              >
                <Text
                  style={[
                    styles.badge,
                    {
                      backgroundColor:
                        rec.impact === "high"
                          ? SEVERITY_COLORS.critical
                          : rec.impact === "medium"
                            ? SEVERITY_COLORS.warning
                            : SEVERITY_COLORS.info,
                    },
                  ]}
                >
                  {rec.impact} impact
                </Text>
                <Text style={styles.cardTitle}>{rec.title}</Text>
              </View>
              <Text style={styles.cardText}>{rec.description}</Text>
            </View>
          ))}
        </>
      )}

      {/* Quick wins */}
      {insights.quickWins && insights.quickWins.length > 0 && (
        <>
          <SectionTitle title="Quick Wins" />
          <Text style={[styles.paragraph, { marginBottom: 10 }]}>
            Low-effort improvements you can implement today for an immediate
            impact.
          </Text>
          {insights.quickWins.map((qw, i) => (
            <View style={styles.card} key={i} wrap={false}>
              <Text style={styles.cardTitle}>
                {i + 1}. {qw.title}
                {qw.effort ? (
                  <Text style={{ color: C.slate, fontWeight: 400 }}>
                    {" "}
                    — {qw.effort}
                  </Text>
                ) : null}
              </Text>
              <Text style={styles.cardText}>{qw.description}</Text>
            </View>
          ))}
        </>
      )}

      {/* 30-day action plan */}
      {insights.actionPlan && insights.actionPlan.length > 0 && (
        <>
          <SectionTitle title="30-Day Action Plan" />
          {insights.actionPlan.map((week, i) => (
            <View style={styles.weekCard} key={i} wrap={false}>
              <Text style={styles.weekTitle}>Week {week.week}</Text>
              {week.focus ? (
                <Text style={styles.weekFocus}>{week.focus}</Text>
              ) : null}
              <Bullets items={week.tasks} />
            </View>
          ))}
        </>
      )}

      {/* Final summary */}
      <SectionTitle title="Final Summary" />
      <Text style={styles.paragraph}>
        {insights.conclusion ??
          `Your website scored ${Math.round(audit.overallScore)}/100 overall. By addressing the critical issues and following the 30-day action plan, meaningful gains in search visibility, page speed and user experience are well within reach. Re-run this audit after implementing the recommendations to measure your progress.`}
      </Text>
      <Text style={[styles.paragraph, { marginTop: 10 }]}>
        Questions about this report? Contact {branding.companyName} at{" "}
        {branding.contactEmail}
        {branding.contactPhone ? ` or ${branding.contactPhone}` : ""}.
      </Text>
    </>
  );
}

// ---------------------------------------------------------------------------
// Document
// ---------------------------------------------------------------------------

export interface AuditReportTemplateProps {
  branding: Branding;
  audit: AuditResultData;
}

export function AuditReportTemplate({
  branding,
  audit,
}: AuditReportTemplateProps) {
  return (
    <Document
      title={`Website Audit Report — ${audit.url}`}
      author={branding.companyName}
      subject="AI-Powered Website Audit"
      creator={`${branding.companyName} (WebGrow AI)`}
    >
      <CoverPage branding={branding} audit={audit} />
      <Page size="A4" style={styles.page}>
        <ReportContent branding={branding} audit={audit} />
        <Footer branding={branding} />
      </Page>
    </Document>
  );
}

/**
 * Render the report template to a PDF Buffer (server-side).
 * Kept here so the template owns its own rendering pipeline.
 */
export async function renderReportPdf(
  props: AuditReportTemplateProps
): Promise<Buffer> {
  return renderToBuffer(<AuditReportTemplate {...props} />);
}

export default AuditReportTemplate;
