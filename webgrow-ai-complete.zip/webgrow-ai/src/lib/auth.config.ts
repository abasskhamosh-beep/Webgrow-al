import type { NextAuthConfig } from "next-auth";

/**
 * Edge-safe Auth.js config — shared between middleware and the Node runtime setup.
 * Must not import Prisma or bcrypt (they are not edge-compatible).
 */
export const authConfig = {
  pages: { signIn: "/login" },
  providers: [], // Credentials provider is added in auth.ts (Node runtime only).
  session: { strategy: "jwt" },
  callbacks: {
    authorized({ auth, request: { nextUrl } }) {
      const isLoggedIn = !!auth?.user;
      const protectedPaths = ["/dashboard", "/audits", "/websites", "/reports", "/settings"];
      const isProtected = protectedPaths.some((p) => nextUrl.pathname.startsWith(p));
      return isProtected ? isLoggedIn : true;
    },
  },
} satisfies NextAuthConfig;
