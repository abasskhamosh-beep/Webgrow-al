/**
 * WebGrow AI — API Authorization Guards
 *
 * Provides route-level auth guards and a withAuth wrapper for Next.js
 * App Router API routes.
 */

import { auth } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import type { Session } from "next-auth";

// ─── Plan hierarchy ───────────────────────────────────────────────────────────

export type Plan = "FREE" | "PRO" | "AGENCY";

const PLAN_RANK: Record<Plan, number> = {
  FREE: 0,
  PRO: 1,
  AGENCY: 2,
};

// ─── Extended session type ────────────────────────────────────────────────────

interface AppSession extends Session {
  user: Session["user"] & {
    id: string;
    plan: Plan;
    role?: "admin" | "user";
  };
}

// ─── Guards ───────────────────────────────────────────────────────────────────

/**
 * Ensures request has a valid authenticated session.
 * Returns the session or a 401 NextResponse.
 */
export async function requireAuth(
  req: NextRequest
): Promise<AppSession | NextResponse> {
  const session = (await auth()) as AppSession | null;

  if (!session?.user?.id) {
    return NextResponse.json(
      { error: "Unauthorized", message: "Authentication required." },
      { status: 401 }
    );
  }

  return session;
}

/**
 * Ensures the authenticated user holds at least the required plan tier.
 * FREE < PRO < AGENCY
 */
export async function requirePlan(
  req: NextRequest,
  minimumPlan: Plan
): Promise<AppSession | NextResponse> {
  const result = await requireAuth(req);
  if (result instanceof NextResponse) return result;

  const session = result as AppSession;
  const userRank = PLAN_RANK[session.user.plan ?? "FREE"];
  const requiredRank = PLAN_RANK[minimumPlan];

  if (userRank < requiredRank) {
    return NextResponse.json(
      {
        error: "Forbidden",
        message: `This action requires the ${minimumPlan} plan or higher.`,
      },
      { status: 403 }
    );
  }

  return session;
}

/**
 * Ensures the authenticated user has the admin role.
 */
export async function requireAdmin(
  req: NextRequest
): Promise<AppSession | NextResponse> {
  const result = await requireAuth(req);
  if (result instanceof NextResponse) return result;

  const session = result as AppSession;

  if (session.user.role !== "admin") {
    return NextResponse.json(
      { error: "Forbidden", message: "Admin access required." },
      { status: 403 }
    );
  }

  return session;
}

// ─── withAuth wrapper ─────────────────────────────────────────────────────────

type RouteHandler = (
  req: NextRequest,
  session: AppSession,
  context?: { params: Record<string, string> }
) => Promise<NextResponse>;

interface WithAuthOptions {
  minimumPlan?: Plan;
  adminOnly?: boolean;
}

/**
 * Wraps a route handler with centralized auth/plan/admin checks.
 * Eliminates boilerplate across API routes.
 *
 * @example
 * export const GET = withAuth(async (req, session) => {
 *   return NextResponse.json({ userId: session.user.id });
 * }, { minimumPlan: "PRO" });
 */
export function withAuth(
  handler: RouteHandler,
  options: WithAuthOptions = {}
) {
  return async function (
    req: NextRequest,
    context?: { params: Record<string, string> }
  ): Promise<NextResponse> {
    let guardResult: AppSession | NextResponse;

    if (options.adminOnly) {
      guardResult = await requireAdmin(req);
    } else if (options.minimumPlan) {
      guardResult = await requirePlan(req, options.minimumPlan);
    } else {
      guardResult = await requireAuth(req);
    }

    if (guardResult instanceof NextResponse) return guardResult;

    try {
      return await handler(req, guardResult as AppSession, context);
    } catch (error) {
      console.error("[withAuth] Unhandled route error:", error);
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 }
      );
    }
  };
}
