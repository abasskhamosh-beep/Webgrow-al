// Plan limits and pricing for WebGrow AI.
export type PlanName = "FREE" | "PRO" | "AGENCY";

export interface PlanLimits {
  auditsPerMonth: number;
  aiPlans: boolean;
  pdfExport: boolean;
  websites: number;
}

export const PLAN_LIMITS: Record<PlanName, PlanLimits> = {
  FREE: { auditsPerMonth: 3, aiPlans: false, pdfExport: false, websites: 1 },
  PRO: { auditsPerMonth: 100, aiPlans: true, pdfExport: true, websites: 10 },
  AGENCY: { auditsPerMonth: 1000, aiPlans: true, pdfExport: true, websites: 100 },
};

export const PLAN_PRICES: Record<PlanName, { display: string; priceId?: string }> = {
  FREE: { display: "$0" },
  PRO: { display: "$29", priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_PRO },
  AGENCY: { display: "$99", priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_AGENCY },
};
