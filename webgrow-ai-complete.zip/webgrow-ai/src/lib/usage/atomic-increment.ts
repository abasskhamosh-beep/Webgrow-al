/**
 * WebGrow AI — Atomic Usage Increment
 *
 * Uses Prisma $transaction with Serializable isolation to safely
 * increment scan counts and prevent race conditions.
 */

import { db } from "@/lib/db";
import { getPlanLimits } from "@/lib/plans";
import type { Plan } from "@/lib/api-auth";

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Returns the first day of the current UTC month as a Date.
 * Used as a consistent bucket key to avoid timezone drift.
 */
export function utcMonth(date: Date = new Date()): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface IncrementResult {
  allowed: boolean;
  used: number;
  limit: number;
  remaining: number;
}

// ─── Atomic increment ─────────────────────────────────────────────────────────

/**
 * Atomically checks and increments the scan count for a user within the
 * current UTC month. Aborts (without incrementing) if the plan limit is
 * already reached.
 *
 * Isolation level: Serializable — prevents phantom reads between the check
 * and the update when concurrent requests arrive simultaneously.
 */
export async function atomicIncrementScanUsage(
  userId: string,
  plan: Plan
): Promise<IncrementResult> {
  const limits = getPlanLimits(plan);
  const monthBucket = utcMonth();

  const result = await db.$transaction(
    async (tx) => {
      // Upsert guarantees the row exists before we read it, eliminating
      // "row not found" races on a user's very first scan of the month.
      await tx.usageRecord.upsert({
        where: {
          userId_month: { userId, month: monthBucket },
        },
        create: {
          userId,
          month: monthBucket,
          scanCount: 0,
        },
        update: {},
      });

      const record = await tx.usageRecord.findUniqueOrThrow({
        where: {
          userId_month: { userId, month: monthBucket },
        },
        select: { scanCount: true },
      });

      if (record.scanCount >= limits.scansPerMonth) {
        return {
          allowed: false,
          used: record.scanCount,
          limit: limits.scansPerMonth,
          remaining: 0,
        };
      }

      const updated = await tx.usageRecord.update({
        where: {
          userId_month: { userId, month: monthBucket },
        },
        data: { scanCount: { increment: 1 } },
        select: { scanCount: true },
      });

      return {
        allowed: true,
        used: updated.scanCount,
        limit: limits.scansPerMonth,
        remaining: limits.scansPerMonth - updated.scanCount,
      };
    },
    {
      isolationLevel: "Serializable",
      timeout: 10_000,
    }
  );

  return result;
}
