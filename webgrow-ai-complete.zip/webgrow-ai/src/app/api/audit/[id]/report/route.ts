/**
 * WebGrow AI — GET /api/audit/[id]/report
 *
 * Streams a downloadable PDF audit report.
 *
 * Schema notes (prisma/schema.prisma):
 *  - The audit model is `Audit` (not AuditResult); scores are Int? columns.
 *  - There is no WhiteLabelSettings model yet — mergeWhiteLabelBranding is
 *    called with null so reports render with default WebGrow AI branding.
 *  - Plan tier lives on the user's `subscription.plan` (Plan enum: FREE/PRO/AGENCY).
 */

import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { canWhiteLabel } from "@/lib/pdf/white-label";
import { generateReport } from "@/lib/pdf/report-generator";
import type {
  AuditIssue,
  AuditResultData,
  PlanTier,
} from "@/lib/pdf/types";

const PLAN_VALUES = ["FREE", "PRO", "AGENCY"] as const;

function toPlanTier(plan: string | null | undefined): PlanTier | undefined {
  return PLAN_VALUES.includes(plan as (typeof PLAN_VALUES)[number])
    ? (plan as PlanTier)
    : undefined;
}

const CATEGORY_MAP: Record<string, string> = {
  SEO: "seo",
  PERFORMANCE: "performance",
  MOBILE: "mobile",
  ACCESSIBILITY: "accessibility",
  CONTENT: "content",
  SECURITY: "security",
};

const SEVERITY_MAP: Record<string, "critical" | "warning" | "info"> = {
  CRITICAL: "critical",
  HIGH: "critical",
  MEDIUM: "warning",
  LOW: "warning",
  INFO: "info",
};

function toAuditResultData(audit: {
  id: string;
  url: string;
  overallScore: number | null;
  seoScore: number | null;
  performanceScore: number | null;
  mobileScore: number | null;
  accessibilityScore: number | null;
  contentScore: number | null;
  rawData: unknown;
  aiPlan: unknown;
  createdAt: Date;
  issues: {
    category: string;
    severity: string;
    title: string;
    description: string;
    howToFix: string | null;
  }[];
}): AuditResultData {
  const issues: AuditIssue[] = audit.issues.map((issue) => ({
    title: issue.title,
    severity: SEVERITY_MAP[issue.severity] ?? "info",
    description: issue.description,
    category: (CATEGORY_MAP[issue.category] ?? "seo") as AuditIssue["category"],
    recommendation: issue.howToFix ?? undefined,
  }));

  const insights = (audit.aiPlan ?? null) as AuditResultData["aiInsights"];

  return {
    id: audit.id,
    url: audit.url,
    createdAt: audit.createdAt,
    overallScore: audit.overallScore ?? 0,
    seoScore: audit.seoScore ?? 0,
    performanceScore: audit.performanceScore ?? 0,
    mobileScore: audit.mobileScore ?? 0,
    accessibilityScore: audit.accessibilityScore ?? 0,
    contentScore: audit.contentScore ?? 0,
    securityScore: 100,
    issues: { issues },
    aiInsights: insights,
  };
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const userId = session.user.id;

    const audit = await db.audit.findFirst({
      where: { id, userId },
      include: {
        issues: {
          orderBy: { order: "asc" },
          select: {
            category: true,
            severity: true,
            title: true,
            description: true,
            howToFix: true,
          },
        },
        user: { select: { subscription: { select: { plan: true } } } },
      },
    });

    if (!audit) {
      return NextResponse.json(
        { error: "Audit not found" },
        { status: 404 }
      );
    }

    const plan = toPlanTier(audit.user.subscription?.plan);
    const whiteLabelAllowed = canWhiteLabel(plan);
    // No WhiteLabelSettings model exists in the schema yet; pass null so the
    // generator falls back to default WebGrow AI branding.
    const whiteLabelSettings = null;

    const report = await generateReport({
      audit: toAuditResultData(audit),
      whiteLabelSettings: whiteLabelAllowed ? whiteLabelSettings : null,
      planTier: plan,
    });

    return new NextResponse(new Uint8Array(report.buffer), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${report.fileName}"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    console.error("[audit-report] PDF generation failed:", error);
    return NextResponse.json(
      { error: "Failed to generate report" },
      { status: 500 }
    );
  }
}
